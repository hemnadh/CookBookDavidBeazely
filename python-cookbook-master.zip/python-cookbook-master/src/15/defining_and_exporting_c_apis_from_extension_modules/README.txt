To build, you need to perform these two steps:

% python3 setup.py build_ext --inplace
% python3 ptsetup.py build_ext --inplace
