import mymodule
a = mymodule.A()
a.spam()

b = mymodule.B()
b.bar()
