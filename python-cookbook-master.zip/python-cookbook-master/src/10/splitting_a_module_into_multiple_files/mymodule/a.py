# a.py

class A:
    def spam(self):
        print('A.spam')

